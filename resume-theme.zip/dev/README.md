# Resume-Generator Dev

Create a theme for ineedaresu.me.

##Super duper simple.

1) Download the theme dev zip from here or at http://ineedaresu.me/resume-theme.zip

2) Open the index.html file in your browser.

3) Edit the THEME.CSS file to change how the resume looks - don't edit the index.html file because that is staying the same on ineedaresu.me

  3.5) Edit js/tests.js to change the content of the resume.
    
4) If you think your theme is pretty good, email it to me at mitch@mitchs.co and I'll put it on ineedaresu.me if I like it!
